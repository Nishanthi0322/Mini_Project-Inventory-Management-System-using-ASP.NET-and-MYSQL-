using Microsoft.EntityFrameworkCore;
using InventoryManagementSystem.Data;  // Correct namespace for your ApplicationDbContext

var builder = WebApplication.CreateBuilder(args);

// Retrieve connection string from appsettings.json or other configuration sources
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

if (string.IsNullOrEmpty(connectionString))
{
    throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
}

// Register the ApplicationDbContext with MySQL
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySQL(connectionString));

// Add services to the container for MVC
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    // In development environment, show detailed exception page for debugging
    app.UseDeveloperExceptionPage();
}
else
{
    // In production environment, show generic error page
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();  // Enforces the use of HTTPS
}

// Redirect HTTP requests to HTTPS
app.UseHttpsRedirection();

// Enable static file serving (e.g., CSS, JavaScript, images)
app.UseStaticFiles();

// Enable routing in the app
app.UseRouting();

// Use authorization middleware (if you have authentication and authorization)
app.UseAuthorization();

// Configure default route for the app
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();  // Start the application
