﻿namespace InventoryManagementSystem.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; } // Nullable string for the request ID
        public string? ErrorMessage { get; set; } // New property for error message
        public int? StatusCode { get; set; } // New property for HTTP status code

        // Property to check if RequestId is present
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        // Property to check if the error message should be shown
        public bool ShowErrorMessage => !string.IsNullOrEmpty(ErrorMessage);
    }
}
