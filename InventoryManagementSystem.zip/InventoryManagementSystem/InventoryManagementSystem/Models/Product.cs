﻿namespace InventoryManagementSystem.Models
{
    public class Product
    {
        public int Id { get; set; }  // Primary key

        public string Name { get; set; } = string.Empty; // Default value to avoid null errors

        public int Quantity { get; set; }

        public decimal Price { get; set; }
    }
}
